
public class Cuenta {

	private String NombreC;
	private String Contra;
	private String Nick;
	private int nivel;
	private int rp;
	private int cantidadpersonaje;
	private Personaje personaje;
	private Skin skin;
	
	
	public Cuenta(String NombreC,String Contra,String Nick, int nivel, int rp,int cantidadpersonaje) {
		this.NombreC= NombreC;
		this.Contra=Contra;
		this.Nick=Nick;
		this.nivel=nivel;
		this.rp=rp;
		this.cantidadpersonaje=cantidadpersonaje;
		
		personaje = null;
		skin= null;
		
	}
	public int getCantidadpersonaje() {
		return cantidadpersonaje;
	}
	public void setCantidadpersonaje(int cantidadpersonaje) {
		this.cantidadpersonaje = cantidadpersonaje;
	}
	public String getNombreC() {
		return NombreC;
	}

	public void setNombreC(String nombreC) {
		NombreC = nombreC;
	}

	public String getContra() {
		return Contra;
	}
	public void setContra(String contra) {
		Contra = contra;
	}
	public String getNick() {
		return Nick;
	}
	public void setNick(String nick) {
		Nick = nick;
	}
	public int getNivel() {
		return nivel;
	}
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}
	public int getRp() {
		return rp;
	}
	public void setRp(int rp) {
		this.rp = rp;
	}
	public Personaje getPersonaje() {
		return personaje;
	}
	public void setPersonaje(Personaje personaje) {
		this.personaje = personaje;
	}
	public Skin getSkin() {
		return skin;
	}
	public void setSkin(Skin skin) {
		this.skin = skin;
	}
	

}
