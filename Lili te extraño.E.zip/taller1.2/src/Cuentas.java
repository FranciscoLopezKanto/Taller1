
public class Cuentas {

	private int cantidadcuenta;
	private int max;
	private Cuenta [] lista;
	
	public Cuentas(int max) {
		lista = new Cuenta[max];
		cantidadcuenta = 0;
		this.max = max;
	}
	public boolean ingresarCuenta(Cuenta cuenta){
		if (cantidadcuenta < max){
			lista[cantidadcuenta]= cuenta;
			cantidadcuenta ++;
			return true;
		}
		else{
			return false;
		}
	}
	
	public Cuenta getCuentaI(int i){
		if (i >=0 && i < cantidadcuenta){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Cuenta buscarCuenta(String nick){
		int i;
		for(i = 0; i < cantidadcuenta; i++){
			if (lista[i].getNick().equals(nick)){
				break;
			}
		}
			if (i == cantidadcuenta){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getCantidadcuenta() {
		return cantidadcuenta;
	}
	public void setCantidadcuenta(int cantidadcuenta) {
		this.cantidadcuenta = cantidadcuenta;
	}

	
}
