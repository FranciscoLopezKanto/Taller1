import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import ucn.StdOut;



public class SistemaCuentasImpl implements SistemaCuentas {
	
	private static Skins lskin;
	private static Personajes lpersonaje;
	private static Cuentas lcuenta;
	private static Estadisticas lestadistica;
	private static LSkinsObtenidas lskino;
	
	
	public SistemaCuentasImpl() throws IOException {
		lskin = new Skins(100000);
		lpersonaje = new Personajes(100000);
		lcuenta = new Cuentas(100000);
		lestadistica = new Estadisticas(100000);
		lskino = new LSkinsObtenidas(10000);
	}
	
	
	/**
	 * Method to enter accounts into the system
	 
	 * */
	public boolean ingresarCuentas(String NombreC, String Contra, String Nick, int nivel, int rp, int cantidadpersonaje) {
		
		Cuenta cuenta = new Cuenta(NombreC,Contra,Nick,nivel,rp, cantidadpersonaje);
		boolean ingreso = lcuenta.ingresarCuenta(cuenta);
		return ingreso;
	}

	/**
	 * Method to enter personage into the system
	 * */
	public boolean ingresarPersonajes(String NombreP, String rol) {
		
		Personaje personaje = new Personaje(NombreP,rol);
		boolean ingreso = lpersonaje.ingresarPersonaje(personaje);
		return ingreso;
	}
	/**
	 * Method to enter skin into the system
	 * */
	
	public boolean ingresarSkins(String NombreSkin, String Calidad) {
		
		Skin skin = new Skin(NombreSkin,Calidad);
		boolean ingreso = lskin.ingresarSkin(skin);
		return ingreso;
	}

	/**
	 * Method to enter statistics into the system
	 * */
	public boolean ingresarEstadisticas(int Recaudacion) {
		
		Estadistica estadistica = new Estadistica(Recaudacion);
		boolean ingreso = lestadistica.ingresarEstadistica(estadistica);
		return ingreso;

		/**
		 * Method to enter obtained skins into the system
		 * */	
	}
	public boolean ingresarSkinObtenidas(String NombreSkin) {
		SkinObtenidas skino = new SkinObtenidas(NombreSkin);
		boolean ingreso = lskino.ingresarSkinO(skino);
		return ingreso;
		
		
	}
	
	/**
	 * method that associates the characters with their respective skins to be used later
	 * */	
	public void asociarPersonajeSkin(String NombrePersonaje, String NombreSkin) {
		
		Personaje personaje = lpersonaje.buscarPersonaje(NombrePersonaje);
		Skin skin = lskin.buscarSkin(NombreSkin);
		if(personaje!=null&&skin!=null) {
			skin.setPersonaje(personaje);	
		}
		else {
			throw new NullPointerException("No existe");
		}
		
	}
	/**
	 * Method to enter account into the system for the list
	 * */
	
	public void AgregarCuenta(String NombreC,String Contra,String Nick, int nivel, int rp, int cantidadpersonaje) {
	
		Cuenta cuenta =new Cuenta(NombreC,Contra,Nick,0,rp, 0);
		lcuenta.ingresarCuenta(cuenta);
		
		/**
		 * Look for the nick position to be used in the program
		 * */	
	}
	public boolean EncontrarNick(String Nick) {
		int i;
		for(i=0;i<lcuenta.getCantidadcuenta();i++) {
			if(lcuenta.getCuentaI(i).getNick().equals(Nick)) {
				break;
			}
		}
		if(i==lcuenta.getCantidadcuenta()) {
			return false;
		}
		else {
			return true;
		}
		/**
		 * Look for the Password position to be used in the program
		 * */	
	}
	public boolean EncontrarContrasena(String contra) {
		int i;
		for(i=0;i<lcuenta.getCantidadcuenta();i++) {
			if(lcuenta.getCuentaI(i).getContra().equals(contra)) {
				break;
			}
		}
		if(i==lcuenta.getCantidadcuenta()) {
			return false;
		}else {
			return true;
		}
	}

	/**
	 * buy a skin for an account
	 * */
	public void ComprarSkin(String NombreSkin) {
		
		int saldo;
		int i;
		int x;
		String a;
		
		for(i=0; i<lskin.getCantidadskin();i++) {
			Cuenta cuenta = lcuenta.getCuentaI(i);
			if(lskin.getSkinI(i).getNombreSkin().equals(NombreSkin)) {
				cuenta.getSkin().getLskin().getSkinI(i).setLskin(lskin);
				a = cuenta.getSkin().getCalidad();
				x = cuenta.getRp();
				if(a.equals("M")) {
					saldo = x - 3250;
					cuenta.setRp(saldo);
					
				}
				else if(a.equals("D")) {
					saldo = x - 2750;
					cuenta.setRp(saldo);
					
				}
				else if(a.equals("L")) {
					saldo = x - 1820;
					cuenta.setRp(saldo);
					
				}
				else if(a.equals("E")) {
					saldo = x - 1350;
					cuenta.setRp(saldo);
					
				}
				else if(a.equals("N")) {
					saldo = x - 975;
					cuenta.setRp(saldo);
					
				}
				
			}
		}
		
	}

	/**
	 * buy a Champ for an account
	 * */
	public void ComprarPersonaje(String NombrePersonaje) {
		int saldo;
		int i;
		int a;
		
		for(i=0; i<lpersonaje.getCantidadpersonaje();i++) {
			Cuenta cuenta = lcuenta.getCuentaI(i);
			if(lpersonaje.getPersonajeI(i).getNombrePersonaje().equals(NombrePersonaje)) {
				cuenta.getPersonaje().getLpersonaje().getPersonajeI(i).setLpersonaje(lpersonaje);
				a = cuenta.getRp();
				saldo = a - 975;
				cuenta.setRp(saldo);
			}
		}
		
		
	}

	/**
	 * Display the skins available for the consulted player
	 * */
	public String ObtenerSkinDisponible(String NombrePersonaje) {
		
		
		
		//comparar skin disponibles con las obtenidas
		return null;
	}

	/**
	 * Request the inventory of the player who is requesting it
	 * */
	public String ObtenerInventario(String Nick) {
		int i;
		String x="Inventario:";
		for(i=0;i<lcuenta.getCantidadcuenta();i++) {
			Cuenta cuenta = lcuenta.getCuentaI(i);
			if(lcuenta.getCuentaI(i).getNick().equals(Nick)){
				for(i=0;i<cuenta.getCantidadpersonaje();i++) {
					x = x+"Personaje"+cuenta.getPersonaje()+", Skin:"+cuenta.getSkin();
				}
				
			}
		}
		
		return x;
		
	}

	/**
	 * RP recharge to player account
	 * */
	public void RecargarRP(int cantidad,String nick) {
		int x;
		int i;
		for(i=0;i<lcuenta.getCantidadcuenta();i++) {
			Cuenta cuenta = lcuenta.getCuentaI(i);
			if(cuenta.getNick().equals(nick)) {
				x = cuenta.getRp()+cantidad;
				cuenta.setRp(x);
			}
		}
	}

	/**
	 * get the account details of the requested player
	 * */
	public String ObtenerDatosCuenta(String Nick) {
		//index string
		String x = "Datos de la cuenta: ";
		
		for(int i=0;i<lcuenta.getCantidadcuenta();i++) {
			Cuenta cuenta = lcuenta.getCuentaI(i);
			if(cuenta.getNick().equals(Nick)) {
				x = x+"Nombre: "+cuenta.getNombreC()+",Nick: "+cuenta.getNick()+",Contrase�a:"+cuenta.getContra();	
				System.out.print("Desea cambiar la contrase�a? SI(S)/NO(N): ");
				Scanner s = new Scanner(System.in);
			    String opcion = s.nextLine().toUpperCase();
			    if(opcion.equals("S")) {
			    	int z = 0;
			    	while(z!=1) {
			    		System.out.print("Ingrese su contrase�a actual");
						Scanner a = new Scanner(System.in);
					    String opcion1 = a.nextLine().toUpperCase();
					    if(opcion1.equals(cuenta.getContra())) {
					    	System.out.print("Ingrese su contrase�a nueva");
					    	Scanner b = new Scanner(System.in);
						    String opcion2 = b.nextLine().toUpperCase();
					    	System.out.print("Ingrese nuevamente su contrase�a nueva");
					    	Scanner c = new Scanner(System.in);
						    String opcion3 = c.nextLine().toUpperCase();
						    if(opcion2.equals(opcion3)) {
						    	System.out.print("Contrase�a actulizada");
						    	z=1;
						    	
						    }
						    else {
						    	System.out.print("Contrase�a erronea");
						    	z=0;
						    	
						    }
					    }
			    	
				    	
				    	
				    }
			    	
			    }
			    else {
			    	
			    }
				
			}
			
			
		}
			
		return x;
	}

	/**
	 * gets the total amount of sales among all characters
	 * */
	public String ObtenerRecaudacionTotalVentas() {
		//sumatoria
		String x = "Recaudacion total: ";
		int total = 0;
		for(int i=0;i<lestadistica.getCantidadestadistica();i++) {
			Estadistica esta = lestadistica.getEstadisticaI(i);
			total += esta.getRecaudacion();
			x = x+total;
		}
			
		
		return x;
	}

	/**
	 * get the total amount of sales among all characters for each role
	 * */
	public String ObtenerRecaudacionVentasPorRol() {
		//sumatoria con condicion
		return null;
	}

	/**
	 * get the total amount of sales for each character
	 * */
	public String ObtenerRecaudacionVentasPorPersonaje() {
		//desplegar individual
		String x = "Recaudacion";
		double s = 6.25;
		for(int i=0;i<lestadistica.getCantidadestadistica();i++) {
			Estadistica esta = lestadistica.getEstadisticaI(i);
			x = x+esta.getPersonaje()+(esta.getRecaudacion()*s);
		}
		return x;
	}

	/**
	 * get the number of characters for each role
	 * */
	public String ObtenerCantidadPersonajePorRol() {
		//condicion en el leer personajes
		return null;
	}

	/**
	 * add a character
	 * */
	public void AgregarPersonaje(String NombrePersonaje, String Rol, String Skin) {
		
		//agrega lista
	}

	/**
	 * Add a skin
	 * */
	public void AgregarSkin(String NombrePersonaje, String Skin, String Calidad) {
		//agrega lista
		
	}

	/**
	 * blocks a player and their username (account number)
	 * */
	public void Bloquearunjugador(String Nick) {
		ArrayList<String> bloqueados = new ArrayList<String>();
		for(int i=0;i<lcuenta.getCantidadcuenta();i++) {
			Cuenta cuenta = lcuenta.getCuentaI(i);
			if(cuenta.getNick().equals(Nick)) {
				bloqueados.add(Nick);
			}
		}
		
	}

	

	/**
	 * is used to display the data of all accounts
	 * */
	public void ObtenerTodasLasCuentas() {
		//desplegar recorre toda la lista cuentas
		//NotPepito, PepitoGamer777,vegetta1111, 434, 12000, 2,Vex,1,Portadora del amanecer,Jhin,2,Oscuridad Cosmica,forajido,LAS
		int i;
		int a=lcuenta.getCantidadcuenta();
		String[] nombre = new String[a];
		int [] niveles = new int[a];
		for(i=0;i<lcuenta.getCantidadcuenta();i++) {
			Cuenta cuenta = lcuenta.getCuentaI(i);
			niveles[i]= cuenta.getNivel();
			nombre[i] = cuenta.getNombreC();
			burbuja(niveles,nombre);
		}
		for(int i1=0;i1<niveles.length;i1++) {
			StdOut.println("Nombre: "+nombre[i1]+", nivel: "+niveles[i1]);
			
		}
		
			
		/**
		 * It is used to sort the data of two lists
		 * */	
	}
	public static void burbuja(int[] A,String [] B) {
        int i, j, aux;
        String aux2;
        for (i = 0; i < A.length - 1; i++) {
            for (j = 0; j < A.length - i - 1; j++) {
                if (A[j + 1] < A[j]) {
                    aux = A[j + 1];
                    aux2 = B[j+1];
                    B[j+1] = B[j];
                    A[j + 1] = A[j];
                    B[j]=aux2;
                    A[j] = aux;
                }
            }
        }
	}
	/**
	 * UPDATE THE DATA INSIDE THE TEXT FILES
	 * */
	public void ActualizarDatos(File arch) {
		
		
	}



	






	
	




	
}
