
public class Estadistica {
	
	private Personaje personaje;
	private int Recaudacion;
	
	public Estadistica(int Recaudacion) {
		this.Recaudacion=Recaudacion;
		personaje=null;
		
	}

	@Override
	public String toString() {
		return "Estadistica [personaje=" + personaje + ", Recaudacion=" + Recaudacion + "]";
	}

	public Personaje getPersonaje() {
		return personaje;
	}

	public void setPersonaje(Personaje personaje) {
		this.personaje = personaje;
	}

	public int getRecaudacion() {
		return Recaudacion;
	}

	public void setRecaudacion(int recaudacion) {
		Recaudacion = recaudacion;
	}
	
}
