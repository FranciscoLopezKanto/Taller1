
public class LSkinsObtenidas {
	private int cantidadskinO;
	private int max;
	private SkinObtenidas [] lista;
	
	public LSkinsObtenidas(int max) {
		lista = new SkinObtenidas[max];
		cantidadskinO = 0;
		this.max = max;
	}
	public boolean ingresarSkinO(SkinObtenidas cuenta){
		if (cantidadskinO < max){
			lista[cantidadskinO]= cuenta;
			cantidadskinO ++;
			return true;
		}
		else{
			return false;
		}
	}
	
	public SkinObtenidas getSkinoI(int i){
		if (i >=0 && i < cantidadskinO){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public SkinObtenidas buscarSkino(String nombre){
		int i;
		for(i = 0; i < cantidadskinO; i++){
			if (lista[i].getNombreSkin().equals(nombre)){
				break;
			}
		}
			if (i == cantidadskinO){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getCantidadskinO() {
		return cantidadskinO;
	}
	public void setCantidadskinO(int cantidadskinO) {
		this.cantidadskinO = cantidadskinO;
	}
	
		
}
