
public class SkinObtenidas {
	private String NombreSkin;
	private String Calidad;
	
	
	public SkinObtenidas(String NombreSkin) {
		
		this.NombreSkin=NombreSkin;
		
	}
	
	public String getNombreSkin() {
		return NombreSkin;
	}
	public void setNombreSkin(String nombreSkin) {
		NombreSkin = nombreSkin;
	}
	public String getCalidad() {
		return Calidad;
	}
	public void setCalidad(String calidad) {
		Calidad = calidad;
	}
	
}
