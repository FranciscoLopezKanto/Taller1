
public class Skin {

	private String NombreSkin;
	private String Calidad;
	private Personaje personaje;
	private Skins lskin;
	
	
	public Skins getLskin() {
		return lskin;
	}


	public void setLskin(Skins lskin) {
		this.lskin = lskin;
	}


	public Skin(String NombreSkin,String Calidad) {
		
		this.NombreSkin=NombreSkin;
		this.Calidad=Calidad;
		personaje=null;
	}


	public String getNombreSkin() {
		return NombreSkin;
	}


	public void setNombreSkin(String nombreSkin) {
		NombreSkin = nombreSkin;
	}


	public String getCalidad() {
		return Calidad;
	}


	public void setCalidad(String calidad) {
		Calidad = calidad;
	}


	public Personaje getPersonaje() {
		return personaje;
	}


	public void setPersonaje(Personaje personaje) {
		this.personaje = personaje;
	}
	
	
	
	
	
}
