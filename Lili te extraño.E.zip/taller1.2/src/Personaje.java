
public class Personaje {

	private String NombrePersonaje;
	private String Rol;
	private Skin skin;
	
	
	private Skins lskin;
	private Personajes lpersonaje;
	
	
	


	public Personajes getLpersonaje() {
		return lpersonaje;
	}

	public void setLpersonaje(Personajes lpersonaje) {
		this.lpersonaje = lpersonaje;
	}

	public Skins getLskin() {
		return lskin;
	}

	public void setLskin(Skins lskin) {
		this.lskin = lskin;
	}

	public Personaje(String NombreP,String rol) {
		this.NombrePersonaje=NombreP;
		this.Rol=rol;
		
	
		skin=null;
		
		
	}

	public String getNombrePersonaje() {
		return NombrePersonaje;
	}



	public void setNombrePersonaje(String nombrePersonaje) {
		NombrePersonaje = nombrePersonaje;
	}



	public String getRol() {
		return Rol;
	}



	public void setRol(String rol) {
		Rol = rol;
	}



	public Skin getSkin() {
		return skin;
	}



	public void setSkin(Skin skin) {
		this.skin = skin;
	}






	
	

	
	
	
}
