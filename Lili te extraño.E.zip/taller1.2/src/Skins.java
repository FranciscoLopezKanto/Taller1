
public class Skins {

	private int cantidadskin;
	private int max;
	private Skin [] lista;
	
	public Skins(int max) {
		lista = new Skin[max];
		cantidadskin = 0;
		this.max = max;
	}
	public boolean ingresarSkin(Skin skin){
		if (cantidadskin < max){
			lista[cantidadskin]= skin;
			cantidadskin ++;
			return true;
		}
		else{
			return false;
		}
	}
	
	public Skin getSkinI(int i){
		if (i >=0 && i < cantidadskin){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Skin buscarSkin(String nombre){
		int i;
		for(i = 0; i < cantidadskin; i++){
			if (lista[i].getNombreSkin().equals(nombre)){
				break;
			}
		}
			if (i == cantidadskin){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getCantidadskin() {
		return cantidadskin;
	}
	public void setCantidadskin(int cantidadskin) {
		this.cantidadskin = cantidadskin;
	}
	
}
