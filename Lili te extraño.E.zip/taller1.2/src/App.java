import java.io.IOException;
import java.util.Scanner;

import ucn.ArchivoEntrada;
import ucn.Registro;
import ucn.StdIn;
import ucn.StdOut;

public class App {
	public static void leer(SistemaCuentas sys) throws IOException  {
		ArchivoEntrada arch=new ArchivoEntrada("Personajes.txt");
		while(!arch.isEndFile()) {
			Registro re=arch.getRegistro();
			String Champ=re.getString();//Campeon
			String Position=re.getString();//Posicion
			int Skins=re.getInt();//NumeroSkins
			for(int i=0;i<Skins;i++) {
				String NameSkin=re.getString();//Nombre Skin
				String Quality=re.getString();//Calidad Skin
				sys.ingresarSkins(NameSkin,Quality);		
			}
			
			sys.ingresarPersonajes(Champ,Position);
			
		}
		arch.close();	
		ArchivoEntrada arch2=new ArchivoEntrada("Cuentas.txt");
		//NotPepito, PepitoGamer777,vegetta1111, 434, 12000, 2,Vex,1,Portadora del 
		//amanecer,Jhin,2,Oscuridad Cosmica,forajido,LAS
		while(!arch2.isEndFile()) {
			Registro registro=arch2.getRegistro();
			String Account=registro.getString();//Nombre cuenta
			String Password=registro.getString();//Contrase�a
			String Nick=registro.getString();//Nick
			int Nivel=registro.getInt();//nivel(max 155)
			int RP=registro.getInt();//rp
			int cantCampeones=registro.getInt();//Cantidad Campeones
			for(int i = 0;i<cantCampeones;i++) {
				String Champ=registro.getString();//Personaje
				int cantSkins=registro.getInt();//Cantidad Skins				
				for(int j=0;j<cantSkins;j++) {
					
					String Skin=registro.getString();//Skin
					sys.asociarPersonajeSkin(Nick, Champ);
					sys.ingresarSkinObtenidas(Skin);
				}
			sys.ingresarCuentas(Account, Password, Nick, Nivel, RP, cantCampeones);
			}
			
			String Region=registro.getString();//Region
			
		}
		arch2.close();
		ArchivoEntrada arch3=new ArchivoEntrada("Estad�sticas.txt");
		while(!arch3.isEndFile()) {
			Registro r=arch3.getRegistro();
			//Sett,500000 ---> esto significa que el personaje Sett obtuvo una recaudaci�n de 500000 RP
			String Champ=r.getString();
			int Recaudacion=r.getInt();
			sys.ingresarEstadisticas(Recaudacion);
		}
	}
	private static void Desplegardatos(SistemaCuentas sys) {
		StdOut.println("Ingrese su nombre de cuenta");
		String dato = StdIn.readString();
		sys.EncontrarNick(dato);
		if(sys.EncontrarNick(dato)!=true) {
			System.out.print("Volver a iniciar sesion");
			
		}
		else if(sys.EncontrarNick(dato)==true) {
			StdOut.println("Ingrese su contrase�a");
			String contra =StdIn.readString();
			sys.EncontrarContrasena(contra);
			if(sys.EncontrarContrasena(contra)!=true){
				System.out.print("Contrase�a incorrecta");
				System.out.print("Volver a iniciar sesion");
			}
			else {
				desplegarMenuCliente();
				System.out.print("Ingrese una opcion (Para salir ingrese 0/ Para MENU ADMIN ingrese 7): ");
				@SuppressWarnings("resource")
				Scanner s = new Scanner(System.in);
				int opcion = s.nextInt();
				if(opcion != 7) {
					while(opcion != 0 && opcion < 8) {
						switch(opcion){
	        	 		case 1:
	        	 			System.out.print("Ingrese el nombre de la skin: ");
	        	 			String skin = StdIn.readString();
	        	 			sys.ComprarSkin(skin);
	        	 		case 2:
	        	 			System.out.print("Ingrese nombre del personaje: ");
	        	 			String perso = StdIn.readString();
	        	 			sys.ComprarPersonaje(perso);;
	        	 		case 3:
	        	 			sys.ObtenerSkinDisponible(dato);
	        			
	        	 		case 4:
	        	 			sys.ObtenerInventario(dato);
	        	 		case 5:
	        	 			System.out.print("Ingrese cantidad que desea recargar: ");
	        	 			int rp = StdIn.readInt();
	        	 			sys.RecargarRP(rp,dato);
	        	 		case 6:
	        	 			sys.ObtenerDatosCuenta(dato);
	        	 			
	        	 			
	        	 		}
		       	 		
					}
				}
				else {
					desplegarMenuAdmin();
					System.out.print("Ingrese una opcion (Para salir ingrese 0)");
					@SuppressWarnings("resource")
					Scanner a = new Scanner(System.in);
					int opcion1 = a.nextInt();
					while(opcion1 != 0 && opcion1 < 9) {
						switch(opcion1) {
						case 1:
							sys.ObtenerRecaudacionVentasPorRol();
						case 2:
							sys.ObtenerRecaudacionTotalVentas();
						case 3:
							sys.ObtenerRecaudacionVentasPorPersonaje();
						case 4:
							sys.ObtenerCantidadPersonajePorRol();
						case 5:
							System.out.print("Ingrese nombre del personaje: ");
							String perso = StdIn.readString();
							System.out.print("Ingrese nombre de la skin: ");
							String skin = StdIn.readString();
							System.out.print("Ingrese la calidad: ");
							String calidad = StdIn.readString();
							sys.AgregarSkin(perso, skin, calidad);
						case 6:
							System.out.print("Ingrese nombre del personaje: ");
							String personaje1 = StdIn.readString();
							System.out.print("Ingrese rol: ");
							String rol1 = StdIn.readString();
							System.out.print("Ingrese skin disponibles: ");
							String skind1 = StdIn.readString();
							sys.AgregarPersonaje(personaje1, rol1, skind1);
						case 7:
							System.out.print("Ingrese nick del jugador a bloquear: ");
							String nickbloqueo = StdIn.readString();
							sys.Bloquearunjugador(nickbloqueo);
						case 8:
							sys.ObtenerTodasLasCuentas();
						
						}
						
					}
					
					
				}
				
	   
			}
			
					
					
		}
				
	}		
	
	public static void desplegarMenuCliente(){
        System.out.println("MENU");
        System.out.println("1) Comprar Skin");
        System.out.println("2) Comprar Personaje");
        System.out.println("3) Skins Disponibles");
        System.out.println("4) Mostrar Inventario");
        System.out.println("5) Recargar RP");
        System.out.println("6) Mostrar Datos de cuenta");
    }
	public static void desplegarMenuAdmin(){
        System.out.println("MENU ADMIN");
        System.out.println("1) Recaudaci�n de ventas por rol");
        System.out.println("2) Recaudaci�n total de ventas ");
        System.out.println("3) Recaudaci�n de ventas por personaje");
        System.out.println("4) Cantidad de personajes por cada rol existente");
        System.out.println("5) Agregar un personaje al juego");
        System.out.println("6) Agregar un skin");
        System.out.println("7) Bloquear a un jugador");
        System.out.println("8) Desplegar todas las cuentas");
    }
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		SistemaCuentas sys = new SistemaCuentasImpl();
		leer(sys);
		Desplegardatos(sys);
		
		
		
	}

}
