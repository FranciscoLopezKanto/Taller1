
public class Personajes {

	private int cantidadpersonaje;
	private int max;
	private Personaje [] lista;
	
	public Personajes(int max) {
		lista = new Personaje[max];
		cantidadpersonaje = 0;
		this.max = max;
	}
	public boolean ingresarPersonaje(Personaje personaje){
		if (cantidadpersonaje < max){
			lista[cantidadpersonaje]= personaje;
			cantidadpersonaje ++;
			return true;
		}
		else{
			return false;
		}
	}
	
	public Personaje getPersonajeI(int i){
		if (i >=0 && i < cantidadpersonaje){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public Personaje buscarPersonaje(String nombre){
		int i;
		for(i = 0; i < cantidadpersonaje; i++){
			if (lista[i].getNombrePersonaje().equals(nombre)){
				break;
			}
		}
			if (i == cantidadpersonaje){
				return null;
		}
		else{
			return lista[i];
		}
	}
	public int getCantidadpersonaje() {
		return cantidadpersonaje;
	}
	public void setCantidadpersonaje(int cantidadpersonaje) {
		this.cantidadpersonaje = cantidadpersonaje;
	}
	
}
