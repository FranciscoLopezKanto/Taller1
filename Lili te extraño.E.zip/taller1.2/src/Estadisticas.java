
public class Estadisticas {
	private int cantidadestadistica;
	private int max;
	private Estadistica [] lista;
	
	public Estadisticas(int max) {
		lista = new Estadistica[max];
		cantidadestadistica = 0;
		this.max = max;
	}
	public boolean ingresarEstadistica(Estadistica estadistica){
		if (cantidadestadistica < max){
			lista[cantidadestadistica]= estadistica;
			cantidadestadistica ++;
			return true;
		}
		else{
			return false;
		}
	}
	
	public Estadistica getEstadisticaI(int i){
		if (i >=0 && i < cantidadestadistica){
			return lista[i];
		}
		else{
			return null;
		}
	}
	public int getCantidadestadistica() {
		return cantidadestadistica;
	}
	public void setCantidadestadistica(int cantidadestadistica) {
		this.cantidadestadistica = cantidadestadistica;
	}

	public Estadistica buscarEstadistica(String nombre){
		int i;
		for(i = 0; i < cantidadestadistica; i++){
			if (lista[i].getPersonaje().equals(nombre)){
				break;
			}
		}
			if (i == cantidadestadistica){
				return null;
		}
		else{
			return lista[i];
		}
	}
}
