import java.io.File;

public interface SistemaCuentas {

	public boolean ingresarCuentas(String NombreC,String Contra,String Nick, int nivel, int rp,int cantidadpersonaje);
	public boolean ingresarPersonajes(String NombreP,String rol);
	public boolean ingresarSkins(String NombreSkin,String Calidad);
	public boolean ingresarEstadisticas(int Recaudacion);
	public boolean ingresarSkinObtenidas(String NombreSkin);
	public void asociarPersonajeSkin(String NombrePersonaje,String NombreSkin);
	public void AgregarCuenta(String NombreC,String Contra,String Nick, int nivel, int rp,int cantidadpersonaje);
	public boolean EncontrarNick(String Nick);
	public boolean EncontrarContrasena(String contra);
	public void ComprarSkin(String NombreSkin);
	public void ComprarPersonaje(String NombrePersonaje);
	public String ObtenerSkinDisponible(String NombrePersonaje);
	public String ObtenerInventario(String Nick);
	public void RecargarRP(int cantidad,String nick); 
	public String ObtenerDatosCuenta(String Nick);
	public String ObtenerRecaudacionTotalVentas();
	public String ObtenerRecaudacionVentasPorRol();
	public String ObtenerRecaudacionVentasPorPersonaje();
	public String ObtenerCantidadPersonajePorRol();
	public void AgregarPersonaje(String NombrePersonaje,String Rol,String Skin);
	public void AgregarSkin(String NombrePersonaje, String Skin,String Calidad);
	public void Bloquearunjugador(String Nick);
	public void ObtenerTodasLasCuentas();
	public void ActualizarDatos(File arch);
	
	
	
		
}
